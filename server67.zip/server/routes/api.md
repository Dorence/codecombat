# API

[Moved](https://codecombat.com/api-docs).
